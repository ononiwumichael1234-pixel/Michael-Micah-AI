# Micah AI — starter project

This is the first **front-end prototype** for Micah AI. It is responsive and includes the installable-web-app foundation (PWA).

## What works now
- Responsive chat-style interface for phones and computers
- "Ask Micah anything" welcome screen
- Suggestion cards and new-chat reset
- Basic installable PWA structure

## What is not connected yet
This is a prototype, not a functioning AI service yet. It does **not** currently:
- generate real AI answers
- generate images
- save accounts or conversations
- provide voice chat or live web search

The preview clearly labels this so users are not misled.

## Run locally
You need a computer with Node.js installed. From this folder, run:

```bash
npx serve public
```

Then open the local address shown in the terminal.

For phone-only development, upload this project to a browser-based coding workspace or Git hosting service, then deploy the `public` folder using a static host.

## Next development stages
1. Add a secure backend (never put private API keys in browser JavaScript).
2. Connect an AI model for real chat.
3. Add sign-in, user-specific conversation storage, and privacy controls.
4. Connect image generation and safe image upload.
5. Add voice, web search, usage limits, and moderation.
6. Deploy the website and package it for Android.

## Important security note
Do not publish API keys in `public/app.js`, HTML, or any client-side file. Store secrets only as server-side environment variables.


## User-selected welcome wallpaper
The welcome panel uses the image supplied by the project owner at `public/micah-wallpaper.jpg`.
The welcome headline and message box use the exact wording: **Ask Michael anything.**
