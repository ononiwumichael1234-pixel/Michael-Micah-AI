const CACHE = 'micah-ai-v2';
const BASE = self.registration.scope;
const FILES = ['', 'index.html', 'styles.css', 'app.js', 'manifest.webmanifest', 'micah-wallpaper.jpg'];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE).then(cache =>
      cache.addAll(FILES.map(file => new URL(file, BASE).toString()))
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(cached =>
      cached || fetch(event.request)
    )
  );
});
