const form=document.querySelector('#chatForm');
const input=document.querySelector('#prompt');
const welcome=document.querySelector('#welcome');
const messages=document.querySelector('#messages');
function addMessage(text,role){const el=document.createElement('div');el.className=`message ${role}`;el.textContent=text;messages.appendChild(el);messages.style.display='flex';welcome.style.display='none';el.scrollIntoView({behavior:'smooth',block:'nearest'});}
function submitPrompt(text){const value=(text||input.value).trim();if(!value)return;addMessage(value,'user');input.value='';setTimeout(()=>addMessage("Thanks for trying Micah AI. The chat interface is working, but the AI brain has not been connected yet. The next build will connect a secure AI service so Micah can generate real answers.",'assistant'),250);}
form.addEventListener('submit',e=>{e.preventDefault();submitPrompt();});
document.querySelectorAll('.suggestion').forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.prompt;input.focus();}));
document.querySelector('#newChat').addEventListener('click',()=>{messages.innerHTML='';messages.style.display='none';welcome.style.display='block';input.value='';document.querySelector('#sidebar').classList.remove('open');});
document.querySelector('#menuBtn').addEventListener('click',()=>document.querySelector('#sidebar').classList.toggle('open'));
document.querySelector('#imageMode').addEventListener('click',()=>{input.value='Create an image of ';input.focus();document.querySelector('#sidebar').classList.remove('open');});
document.querySelector('#attachBtn').addEventListener('click',()=>alert('Image uploads will be added when the secure backend is connected.'));
document.querySelector('#voiceBtn').addEventListener('click',()=>alert('Voice conversations are planned for a future build.'));
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
